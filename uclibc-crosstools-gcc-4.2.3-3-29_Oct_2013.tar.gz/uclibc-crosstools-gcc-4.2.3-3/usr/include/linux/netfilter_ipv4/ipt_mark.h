#ifndef _IPT_MARK_H
#define _IPT_MARK_H

/* Backwards compatibility for old userspace */
#include <linux/netfilter/xt_mark.h>

#define ipt_mark_info xt_mark_info

#endif /*_IPT_MARK_H*/
