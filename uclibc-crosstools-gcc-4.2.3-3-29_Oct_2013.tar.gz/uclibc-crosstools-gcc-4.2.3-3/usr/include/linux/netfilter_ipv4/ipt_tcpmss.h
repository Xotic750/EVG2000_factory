#ifndef _IPT_TCPMSS_MATCH_H
#define _IPT_TCPMSS_MATCH_H

#include <linux/netfilter/xt_tcpmss.h>
#define ipt_tcpmss_match_info xt_tcpmss_match_info

#endif /*_IPT_TCPMSS_MATCH_H*/
