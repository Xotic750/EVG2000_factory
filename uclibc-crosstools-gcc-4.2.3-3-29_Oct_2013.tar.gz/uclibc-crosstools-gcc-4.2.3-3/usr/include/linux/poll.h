#ifndef _LINUX_POLL_H
#define _LINUX_POLL_H

#include <asm/poll.h>


#endif /* _LINUX_POLL_H */
